<?php
//rotas da aplicação
//a variável $uri já contém os dados da rota solicitada

switch ($uri) {
    
        case '/':

        $vestidoController->index();
        
        break;

        case '/login':
        $loginController->login();
        break;
    
        case '/logout':
        
        $loginController->logout();
        break;
    
        case '/home':
        $vestidoController->home();
        
        break;
    
        case '/cliente':
        $vestidoController->cliente();
        
        break;
    
        case '/funcionario':
        $vestidoController->funcionario();
        break;
    
        case '/aluguel':
        $vestidoController->aluguel();
        break;

    
        case '/venda':
        $vestidoController->venda();
        break;
    
        case '/cadastrarCliente':
        
        $vestidoController->cadastrarCliente();
        break;
    
        case '/cadastrarVenda':
        $vestidoController->cadastrarVenda();
        break;
    
        case '/cadastrarAluguel':
        $vestidoController->cadastrarAluguel();
        break;
     
        case '/cadastrarFuncionario':
        $vestidoController->cadastrarFuncionario();
        break;

        case '/savecliente':
        $vestidoController->saveCliente();
        break;

        case '/savefuncionario':
        $vestidoController->saveFuncionario();
        break;

        case '/saveVenda':
        $vestidoController->saveVenda();
        break;
        
        case '/saveAluguel':
        $vestidoController->saveAluguel();
        break;
    
    case '/logout':
    $vestidoController->logout();
        break;
    
    default:
        die('Essa rota não é valida');
        break;
}
