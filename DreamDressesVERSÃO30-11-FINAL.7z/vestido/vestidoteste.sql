-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           5.5.5-10.1.13-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              7.0.0.4362
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Copiando estrutura do banco de dados para vestidoteste
CREATE DATABASE IF NOT EXISTS `vestidoteste` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `vestidoteste`;


-- Copiando estrutura para tabela vestidoteste.aluguel
CREATE TABLE IF NOT EXISTS `aluguel` (
  `nome` varchar(100) DEFAULT NULL,
  `tipovestido` varchar(50) DEFAULT NULL,
  `tamanho` varchar(2) DEFAULT NULL,
  `dataaluguel` date DEFAULT NULL,
  `datadevolucao` date DEFAULT NULL,
  `formapag` varchar(50) DEFAULT NULL,
  `funcresp` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vestidoteste.aluguel: ~1 rows (aproximadamente)
/*!40000 ALTER TABLE `aluguel` DISABLE KEYS */;
INSERT INTO `aluguel` (`nome`, `tipovestido`, `tamanho`, `dataaluguel`, `datadevolucao`, `formapag`, `funcresp`) VALUES
	('Pedro Amalfi', 'Curto', 'G', '2017-10-31', '2017-11-03', 'A vista', 'Nahara dos Santos'),
	('Henrique da Silva', 'Curto', 'P', '2017-11-24', '2017-11-29', 'Mastercard', 'Laura Ribeiro');
/*!40000 ALTER TABLE `aluguel` ENABLE KEYS */;


-- Copiando estrutura para tabela vestidoteste.cliente
CREATE TABLE IF NOT EXISTS `cliente` (
  `nome` varchar(100) DEFAULT NULL,
  `telefone` int(11) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vestidoteste.cliente: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `cliente` DISABLE KEYS */;
INSERT INTO `cliente` (`nome`, `telefone`, `email`) VALUES
	('Iago Faria dos Santos', 997325112, 'santos.iago@gmail.com'),
	('&Eacute;velyn Passoni Montagnini', 38415126, 'e_montagnini@hotmail.com'),
	('Pedro Amalfi', 997842184, 'amalfi.pedro@gmail.com'),
	('Henrique da Silva', 995264857, 'henrique.silva@gmail.com');
/*!40000 ALTER TABLE `cliente` ENABLE KEYS */;


-- Copiando estrutura para tabela vestidoteste.funcionario
CREATE TABLE IF NOT EXISTS `funcionario` (
  `nome` varchar(50) DEFAULT NULL,
  `funcao` varchar(50) DEFAULT NULL,
  `endereco` varchar(100) DEFAULT NULL,
  `telefone` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `salario` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vestidoteste.funcionario: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `funcionario` DISABLE KEYS */;
INSERT INTO `funcionario` (`nome`, `funcao`, `endereco`, `telefone`, `email`, `salario`) VALUES
	('Laura Ribeiro', 'Vendedora', 'Mogi Gua&ccedil;u, Vila para&iacute;so, 272', '999981494', 'lauraribeiro@gmail.com', 1300),
	('Mariana Cardoso', 'Vendedora', 'Mogi Gua&ccedil;u, Jardim Presidente, 333', '37647333', 'marinn@gmail.com', 1233),
	('Nahara dos Santos', 'Vendedora', 'Mogi Gua&ccedil;u', '736736373', 'n@gmail.com', 1400);
/*!40000 ALTER TABLE `funcionario` ENABLE KEYS */;


-- Copiando estrutura para tabela vestidoteste.usuario
CREATE TABLE IF NOT EXISTS `usuario` (
  `rg` int(11) DEFAULT NULL,
  `password` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vestidoteste.usuario: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` (`rg`, `password`) VALUES
	(403583, 243);
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;


-- Copiando estrutura para tabela vestidoteste.venda
CREATE TABLE IF NOT EXISTS `venda` (
  `nome` varchar(50) DEFAULT NULL,
  `tipovestido` varchar(50) DEFAULT NULL,
  `tamanho` varchar(2) DEFAULT NULL,
  `formapag` varchar(50) DEFAULT NULL,
  `funcresp` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela vestidoteste.venda: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `venda` DISABLE KEYS */;
INSERT INTO `venda` (`nome`, `tipovestido`, `tamanho`, `formapag`, `funcresp`) VALUES
	('Iago Faria dos Santos', 'Ombr&egrave;', 'P', 'Mastercard', 'Laura Ribeiro'),
	('&Eacute;velyn Passoni Montagnini', 'Longo', 'M', 'A vista', 'Mariana Cardoso');
/*!40000 ALTER TABLE `venda` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
