<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./public/index/css/styleHOME.css" rel="stylesheet">
    <style>
        
        #a{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            text-align: center;
        }

    </style>
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="icon" href="img/favicon.ico" type="image/x-icon">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="/home">DREAM DRESSES</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
      
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/cliente">CLIENTE</a>
      </li>
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/funcionario">FUNCIONÁRIO</a>
      </li>
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/aluguel">ALUGUEL</a>
      </li>
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/venda">VENDA</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" action="/logout">
      <button class="btn btn-secondary my-7 my-sm-0"  type="submit">SAIR</button>
    </form>
  </div>
</nav>

<div class="jumbotron">
    
<form>
  <fieldset>
<center> <legend>VENDA</legend></center>
    <div class="container">
    <table class="table table-striped table-hover table-bordered">
  <thead class="thead-dark">
  <tr>
  <th>Nome do cliente</th>
  <th>Tipo de vestido</th>
  <th>Tamanho</th>
  <th>Forma de pagamento</th>
  <th>Funcionário responsável</th>
</tr>
</thead>
<tbody>
<?php foreach ($dados as $value) { ?>
  <tr>
    <td>  <?= $value['nome'] ?></td>
    <td>  <?= $value['tipovestido'] ?></td>    
    <td>  <?= $value['tamanho'] ?></td>
    <td>  <?= $value['formapag'] ?></td>    
    <td>  <?= $value['funcresp'] ?></td>
  </tr>
  <?php } ?>


  </tbody>
</table> 
    </div>
    </fieldset>
</form>
    </div>

</body>

</html>