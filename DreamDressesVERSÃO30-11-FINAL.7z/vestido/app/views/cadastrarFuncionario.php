<!DOCTYPE html>
<html lang="en">

<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="./public/index/css/styleHOME.css" rel="stylesheet">
    <style>
        
        #a{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%,-50%);
            text-align: center;
        }

    </style> 
    <link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="icon" href="img/favicon.ico" type="image/x-icon">
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <a class="navbar-brand" href="/home">DREAM DRESSES</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarColor01">
    <ul class="navbar-nav mr-auto">
    
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/cliente">CLIENTE</a>
      </li>
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/funcionario">FUNCIONÁRIO</a>
      </li>
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/aluguel">ALUGUEL</a>
      </li>
      <li class="nav-item" action="" method="post">
        <a class="nav-link" href="/venda">VENDA</a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0" action="/logout">
      <button class="btn btn-secondary my-7 my-sm-0"  type="submit">SAIR</button>
    </form>
  </div>
</nav>
<div class="jumbotron">
    
<form method="post" action="/savefuncionario">
  <fieldset>
   <center> <legend>CADASTRO DE FUNCIONÁRIO</legend></center>
   <div class="form-group">
   <label for="exampleInputNome1">Nome completo</label>
   <input name="nome" type="TEXT" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" >
  
 </div>
    <div class="form-group">
      <label for="exampleInputVestido1">Função</label>
      <input name="funcao" type="phone" class="form-control" id="exampleInputPassword1" >
    </div>
    <div class="form-group">
      <label for="exampleInputVestido1">Endereço</label>
      <input name="endereco" type="phone" class="form-control" id="exampleInputPassword1" >
    </div>
    
    <div class="form-group">
      <label for="exampleInputVestido1">Telefone</label>
      <input name="telefone" type="phone" class="form-control" id="exampleInputPassword1" >
    </div>
    
    <div class="form-group">
    <label for="exampleInputVestido1">Email</label>
    <input name="email" type="phone" class="form-control" id="exampleInputPassword1" >
  </div>

      <div class="form-group">
      <label for="exampleInputVestido1">Salário</label>
      <input name="salario" type="real" class="form-control" id="exampleInputPassword1" >
    </div>
   
    <br>
    <button type="submit" class="btn btn-primary">ENVIAR</button>
  </fieldset>
</form>
    </div>

</body>

</html>