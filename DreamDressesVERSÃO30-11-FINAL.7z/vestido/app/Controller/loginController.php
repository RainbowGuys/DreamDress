<?php
namespace Project\Controller;
use Project\Db\QueryBuilder;
use Project\Util\Flash;

class LoginController
{
    public function login()
        {
            $dados['rg'] = htmlentities($_POST['rg'], ENT_QUOTES);
            $dados['password'] = htmlentities($_POST['password'], ENT_QUOTES);

            $q = new QueryBuilder();
            
            $logou = $q->select('usuario', [
                'rg' => $dados['rg'], 
                'password' => $dados['password']
            ]);                                              
            
            if (!$logou) {
                Flash::setFlash('Login não encontrado.');
                header('Location: /');
                exit;
            
            }
            // se o usuário não foi encontrado no banco de dados
            // emite uma mensagem de erro
             
            // autentica o usuário
            $_SESSION['usuario'] = $dados['rg'];
            
            header('Location: /home');
        }
public function logout(){
            //remove todas variáveis criadas de sessão
            session_unset();
            //devolve para a página inicial
            header('Location: /');
        }
    
    }
