<?php
namespace Project\Controller;
use Project\Db\QueryBuilder;
use Project\Util\Login;
use Project\Util\Flash;
class VestidoController
{
    public function index()
    {

        //se ele ja esta logado para redirecionar
        if(Login::isLogged()){
            header('Location: /home');
            exit;
        }

        $flash = Flash::getFlash();

        require './app/views/index.php';
        
    }

    public function home()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        require './app/views/home.php';
        
    }


    public function saveCliente()
    {

        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }
  

        $dados['nome'] = htmlentities($_POST['nome'], ENT_QUOTES);
        $dados['telefone'] = htmlentities($_POST['telefone'], ENT_QUOTES);
        $dados['email'] = htmlentities($_POST['email'], ENT_QUOTES);


        $q = new QueryBuilder();
       $cadastrado = $q->insert('cliente', $dados);

    
       header('Location: /home');

    }
    
    public function venda()
    {

        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

         $q = new QueryBuilder();
         $dados = $q->select('venda');

         require './app/views/venda.php';
    }

    public function funcionario()
    {

        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

         $q = new QueryBuilder();
         $dados = $q->select('funcionario');

         require './app/views/funcionario.php';
    }

    public function aluguel()
    {

        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

         $q = new QueryBuilder();
         $dados = $q->select('aluguel');

         require './app/views/aluguel.php';
    }


    
    public function saveFuncionario()
    {

        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        $dados['nome'] = htmlentities($_POST['nome'], ENT_QUOTES);
        $dados['funcao'] = htmlentities($_POST['funcao'], ENT_QUOTES);
        $dados['endereco'] = htmlentities($_POST['endereco'], ENT_QUOTES);        
        $dados['telefone'] = htmlentities($_POST['telefone'], ENT_QUOTES);
        $dados['email'] = htmlentities($_POST['email'], ENT_QUOTES);
        $dados['salario'] = htmlentities($_POST['salario'], ENT_QUOTES);
     

        $q = new QueryBuilder();
        $cadastrado = $q->insert('funcionario', $dados);
 
     
        header('Location: /home');
 
    }
    public function saveVenda()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        $dados['nome'] = htmlentities($_POST['nome'], ENT_QUOTES);
        $dados['tipovestido'] = htmlentities($_POST['tipovestido'], ENT_QUOTES);        
        $dados['tamanho'] = htmlentities($_POST['tamanho'], ENT_QUOTES);
        $dados['formapag'] = htmlentities($_POST['formapag'], ENT_QUOTES);
        $dados['funcresp'] = htmlentities($_POST['funcresp'], ENT_QUOTES);



        $q = new QueryBuilder();
       $cadastrado = $q->insert('venda', $dados);

    
       header('Location: /home');
    }
    public function saveAluguel()
    {

        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        
        $dados['nome'] = htmlentities($_POST['nome'], ENT_QUOTES);
        $dados['tipovestido'] = htmlentities($_POST['tipovestido'], ENT_QUOTES);                
        $dados['tamanho'] = htmlentities($_POST['tamanho'], ENT_QUOTES);
        $dados['dataaluguel'] = htmlentities($_POST['dataaluguel'], ENT_QUOTES);  
        $return= new \DateTime($message['dataaluguel']);
        echo $return->format('y/m/d');      
        $dados['datadevolucao'] = htmlentities($_POST['datadevolucao'], ENT_QUOTES);
        $return= new \DateTime($message['datadevolucao']);
        echo $return->format('y/m/d'); 
        $dados['formapag'] = htmlentities($_POST['formapag'], ENT_QUOTES);
        $dados['funcresp'] = htmlentities($_POST['funcresp'], ENT_QUOTES);


        $q = new QueryBuilder();
       $cadastrado = $q->insert('aluguel', $dados);

    
       header('Location: /home');

    }

    public function cliente()
    {
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        
        $q = new QueryBuilder();
        $dados = $q->select('cliente');

        require './app/views/cliente.php';
        
    }

    public function cadastrarCliente(){
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }


        require './app/views/cadastrarCliente.php';
    }

    public function cadastrarAluguel(){
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        require './app/views/cadastrarAluguel.php';
    }

public function cadastrarFuncionario(){
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        require './app/views/cadastrarFuncionario.php';
    }

    public function cadastrarVenda(){
        if(!Login::isLogged()){
            header('Location: /');
            exit;
        }

        require './app/views/cadastrarVenda.php';
    }


    public function Logout(){

        session_destroy();
        header('Location: /');
      
    }


}

